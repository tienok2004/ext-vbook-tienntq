function execute() {
    return Response.success([
        { title: "Cập Nhật", input: "https://sayhentai.fun", script: "gen.js" },
        { title: "Manhwa", input: "https://sayhentai.fun/genre/manhwa", script: "gen.js" },
        { title: "Manga", input: "https://sayhentai.fun/genre/manga", script: "gen.js" },
        { title: "Manhua", input: "https://sayhentai.fun/genre/manhua", script: "gen.js" },
    ]);
}