function execute() {
    return Response.success([
        {title: "Cập Nhật", input: "https://damconuong.onl/danh-sach", script: "cat.js"},
        {title: "Manhwa", input: "https://damconuong.onl/the-loai/manhwa", script: "cat.js"},
    ]);
}