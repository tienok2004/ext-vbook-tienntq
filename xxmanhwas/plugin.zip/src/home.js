function execute() {
    return Response.success([
        { title: "All", input: "tat-ca-cac-truyen", script: "gen.js" },
    ]);
}