function execute() {
    return Response.success([
        {title: "Cập Nhật", input: "https://hentaivnhot.net/truyen-hentai-moi", script: "gen.js"},
        {title: "Hot Tuần", input: "https://hentaivnhot.net/truyen-hot", script: "gen.js"},
        {title: "Full Color", input: "https://hentaivnhot.net/the-loai/full-color", script: "gen.js"},
        {title: "Không Che", input: "https://hentaivnhot.net/the-loai/khong-che", script: "gen.js"},
    ]);
}