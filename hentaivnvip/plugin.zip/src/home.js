function execute() {
    return Response.success([
        {title: "Cập Nhật", input: "https://hentaivn.gold/truyen-hentai/", script: "cat.js"},
        {title: "Manhwa", input: "https://hentaivn.gold/the-loai/manhwa/", script: "cat.js"},
        {title: "3D Hentai", input: "https://hentaivn.gold/the-loai/3d-hentai/", script: "cat.js"},
    ]);
}