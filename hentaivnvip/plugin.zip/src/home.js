function execute() {
    return Response.success([
        {title: "Cập Nhật", input: "https://hentaivn.gold/truyen-hentai/", script: "cat.js"},
    ]);
}