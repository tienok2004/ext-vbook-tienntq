function execute() {
    return Response.success([
        {
            "input": "/the-loai/3d-hentai/",
            "title": "3D Hentai",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/action/",
            "title": "Action",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/adult/",
            "title": "Adult",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/ahegao/",
            "title": "Ahegao",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/anal/",
            "title": "Anal",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/animal/",
            "title": "Animal",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/artist-cg/",
            "title": "Artist CG",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/bao-dam/",
            "title": "Bạo Dâm",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/bdsm/",
            "title": "BDSM",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/body-swap/",
            "title": "Body Swap",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/big-ass/",
            "title": "Big Ass",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/big-boobs/",
            "title": "Big Boobs",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/big-penis/",
            "title": "Big Penis",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/blowjobs/",
            "title": "BlowJobs",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/bondage/",
            "title": "Bondage",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/bodysuit/",
            "title": "Bodysuit",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/breastjobs/",
            "title": "BreastJobs",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/breast-sucking/",
            "title": "Breast Sucking",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/cosplay/",
            "title": "Cosplay",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/dark-skin/",
            "title": "Dark Skin",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/demon/",
            "title": "Demon",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/dirty-old-man/",
            "title": "Dirty Old Man",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/doujinshi/",
            "title": "Doujinshi",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/ecchi/",
            "title": "Ecchi",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/elf/",
            "title": "Elf",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/exhibitionism/",
            "title": "Exhibitionism",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/femdom/",
            "title": "Femdom",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/full-color/",
            "title": "Full Color",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/furry/",
            "title": "Furry",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/futanari/",
            "title": "Futanari",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/footjob/",
            "title": "Footjob",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/game/",
            "title": "Game",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/gender-bender/",
            "title": "Gender Bender",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/gothic-lolita/",
            "title": "Gothic Lolita",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/guro/",
            "title": "Guro",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/harem/",
            "title": "Harem",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/hentaivn/",
            "title": "HentaiVN",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/housewife/",
            "title": "Housewife",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/horror/",
            "title": "Horror",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/insect-con-trung/",
            "title": "Insect (Côn Trùng)",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/loli/",
            "title": "Loli",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/loan-luan/",
            "title": "Loạn Luân",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/maids/",
            "title": "Maids",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/manhwa/",
            "title": "Manhwa",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/masturbation/",
            "title": "Masturbation",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/milf/",
            "title": "Milf",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/mind-control/",
            "title": "Mind Control",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/monster/",
            "title": "Monster",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/mother/",
            "title": "Mother",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/nurse/",
            "title": "Nurse",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/ntr/",
            "title": "NTR",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/old-man/",
            "title": "Old Man",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/oneshot/",
            "title": "Oneshot",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/pantyhose/",
            "title": "Pantyhose",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/pregnant/",
            "title": "Pregnant",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/rape/",
            "title": "Rape",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/scat/",
            "title": "Scat",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/school-uniform/",
            "title": "School Uniform",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/sex-toys/",
            "title": "Sex Toys",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/sister/",
            "title": "Sister",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/shota/",
            "title": "Shota",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/slave/",
            "title": "Slave",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/sleeping/",
            "title": "Sleeping",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/sports/",
            "title": "Sports",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/teacher/",
            "title": "Teacher",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/tentacles/",
            "title": "Tentacles",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/tomboy/",
            "title": "Tomboy",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/trap/",
            "title": "Trap",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/vampire/",
            "title": "Vampire",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/x-ray/",
            "title": "X-ray",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/yandere/",
            "title": "Yandere",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/yaoi/",
            "title": "Yaoi",
            "script": "cat.js"
        }
    ]);
}