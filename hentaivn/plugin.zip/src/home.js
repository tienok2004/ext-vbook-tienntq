function execute() {
    return Response.success([
        {title: "Truyện mới", input: "https://hentaivn.in/danh-sach.html", script: "gen.js"},
        {title: "Chương mới", input: "https://hentaivn.in/chap-moi.html", script: "gen.js"},
        {title: "Full màu", input: "https://hentaivn.in/the-loai-37-full_color.html", script: "gen.js"},
        {title: "Không che", input: "https://hentaivn.in/the-loai-99-khong_che.html", script: "gen.js"}
    ]);
}